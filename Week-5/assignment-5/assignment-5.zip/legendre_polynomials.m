function p = legendre_polynomials(n, phi)
  # This function computes the Legendre polynomials for m = 0.
  # n: is the degree,
  # phi: is the latitude.
  
  your code goes here...
  