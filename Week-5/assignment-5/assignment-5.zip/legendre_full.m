function p = legendre_full(n , m, phi)
   # This function computes the Legendre polynomials.
  # n: is the degree,
  # m: is the order
  # phi: is the latitude.
  your code goes here...